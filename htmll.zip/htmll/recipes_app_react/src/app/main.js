//main.js
//this will compile to index.js that will have
//the react code on index.html
import App from './App';
