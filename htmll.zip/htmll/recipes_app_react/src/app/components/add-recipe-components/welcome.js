import React from 'react'
import ReactDOM from 'react-dom'

class Welcome extends React.Component {
	render() {
		return (
			<div class="welcome slide">
				We are going to create a receipe!
			</div>
		)
	}
}

export default Welcome