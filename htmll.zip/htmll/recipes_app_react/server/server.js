'use strict';
const app = require("./serverApp.js");
const server_port = process.env.OPENSHIFT_NODEJS_PORT || 3000	;
//const server_ip_address = process.env.OPENSHIFT_NODEJS_IP || '127.0.0.1';

app.listen(server_port, () => {
	console.log("dirname is " + __dirname);
	console.log("----------------------------");
	console.log("Server started on"  + ":" + server_port);
	console.log("----------------------------");
});
